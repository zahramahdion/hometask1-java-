public class StringCharacters {
    public static void main(String[] args) {
        String text = "To be or not to be, that is the question;" +
                " Whether tis nobler in the mind to suffer" +
                " the slings and arrows of outrageous fortune," +
                " or to take arms against a sea of troubles," +
                " and by opposing end them?";

        int spaces = 0;
        int vowels = 0;
        int letters = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);

            if (c == ' ') {
                spaces++;
            }
            else if (Character.isLetter(c)) {
                letters++;

                char lowerC = Character.toLowerCase(c);

                if (lowerC == 'a' | lowerC == 'e' | lowerC == 'i' | lowerC == 'o' | lowerC == 'u') {
                    vowels++;
                }
            }
        }

        System.out.println("The text contained vowels: " + vowels +
                "\nConsonants: " + (letters - vowels) +
                "\nSpaces: " + spaces);
    }
}